Sicherung 2023.

innen.zip           enthaelt Rechnungen und einen Laborbefund
tiefer/noch-tiefer.zip enthaelt innerste.zip enthaelt ende.txt
